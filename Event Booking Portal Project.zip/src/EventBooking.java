import java.sql.*;
import java.util.Scanner;

public class EventBooking {
    static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        while (true) {
            System.out.println("\n--- Event Booking Portal ---");
            System.out.println("1. Register User");
            System.out.println("2. Show Events");
            System.out.println("3. Book Event");
            System.out.println("4. View Bookings");
            System.out.println("5. Exit");
            System.out.print("Enter choice: ");
            int choice = scanner.nextInt();
            scanner.nextLine();

            switch (choice) {
                case 1 -> registerUser();
                case 2 -> showEvents();
                case 3 -> bookEvent();
                case 4 -> viewBookings();
                case 5 -> System.exit(0);
                default -> System.out.println("Invalid choice.");
            }
        }
    }

    private static void registerUser() {
        try (Connection conn = DatabaseConnection.getConnection()) {
            System.out.print("Enter Name: ");
            String name = scanner.nextLine();
            System.out.print("Enter Email: ");
            String email = scanner.nextLine();

            String query = "INSERT INTO users (name, email) VALUES (?, ?)";
            PreparedStatement ps = conn.prepareStatement(query);
            ps.setString(1, name);
            ps.setString(2, email);
            ps.executeUpdate();
            System.out.println("User registered successfully.");
        } catch (SQLException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    private static void showEvents() {
        try (Connection conn = DatabaseConnection.getConnection()) {
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT * FROM events");
            System.out.println("\nAvailable Events:");
            while (rs.next()) {
                System.out.printf("ID: %d | %s | %s | Date: %s\n",
                        rs.getInt("event_id"),
                        rs.getString("title"),
                        rs.getString("description"),
                        rs.getDate("date"));
            }
        } catch (SQLException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    private static void bookEvent() {
        try (Connection conn = DatabaseConnection.getConnection()) {
            System.out.print("Enter your Email: ");
            String email = scanner.nextLine();
            System.out.print("Enter Event ID: ");
            int eventId = scanner.nextInt();
            scanner.nextLine();

            PreparedStatement psUser = conn.prepareStatement("SELECT user_id FROM users WHERE email = ?");
            psUser.setString(1, email);
            ResultSet rsUser = psUser.executeQuery();

            if (!rsUser.next()) {
                System.out.println("User not found. Please register first.");
                return;
            }

            int userId = rsUser.getInt("user_id");

            PreparedStatement psBook = conn.prepareStatement("INSERT INTO bookings (user_id, event_id) VALUES (?, ?)");
            psBook.setInt(1, userId);
            psBook.setInt(2, eventId);
            psBook.executeUpdate();

            System.out.println("Event booked successfully.");
        } catch (SQLException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    private static void viewBookings() {
        try (Connection conn = DatabaseConnection.getConnection()) {
            System.out.print("Enter your Email: ");
            String email = scanner.nextLine();

            String query = "SELECT b.booking_id, e.title, e.date FROM bookings b "
                         + "JOIN users u ON b.user_id = u.user_id "
                         + "JOIN events e ON b.event_id = e.event_id "
                         + "WHERE u.email = ?";

            PreparedStatement ps = conn.prepareStatement(query);
            ps.setString(1, email);
            ResultSet rs = ps.executeQuery();

            System.out.println("\nYour Bookings:");
            while (rs.next()) {
                System.out.printf("Booking ID: %d | Event: %s | Date: %s\n",
                        rs.getInt("booking_id"),
                        rs.getString("title"),
                        rs.getDate("date"));
            }
        } catch (SQLException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
}
