# Console-Based Event Booking System

## How to Run

1. Ensure MySQL server is running.
2. Import `schema.sql` into MySQL to create database and tables.
3. Open the project in IntelliJ.
4. Add MySQL JDBC connector (via Project Structure > Libraries > From Maven):
   mysql:mysql-connector-java:8.0.33
5. Update DB credentials in `DatabaseConnection.java` if needed.
6. Run `EventBooking.java` from IntelliJ console.

Enjoy!
